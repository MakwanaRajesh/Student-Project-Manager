module.exports = [
"[project]/.next-internal/server/app/dashboard/faculty/schedule-meeting/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_dashboard_faculty_schedule-meeting_page_actions_ed7bb0cb.js.map