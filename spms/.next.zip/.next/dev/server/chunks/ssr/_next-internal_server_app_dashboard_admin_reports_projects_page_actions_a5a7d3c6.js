module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/reports/projects/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_reports_projects_page_actions_a5a7d3c6.js.map