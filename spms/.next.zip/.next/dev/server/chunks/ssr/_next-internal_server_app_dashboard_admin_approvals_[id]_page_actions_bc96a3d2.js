module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/approvals/[id]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_approvals_%5Bid%5D_page_actions_bc96a3d2.js.map