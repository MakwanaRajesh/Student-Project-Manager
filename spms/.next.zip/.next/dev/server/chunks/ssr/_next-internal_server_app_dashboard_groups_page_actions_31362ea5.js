module.exports = [
"[project]/.next-internal/server/app/dashboard/groups/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_groups_page_actions_31362ea5.js.map