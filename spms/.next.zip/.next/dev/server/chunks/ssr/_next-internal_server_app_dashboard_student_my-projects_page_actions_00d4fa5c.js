module.exports = [
"[project]/.next-internal/server/app/dashboard/student/my-projects/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_student_my-projects_page_actions_00d4fa5c.js.map