module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/settings/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_settings_page_actions_2f0fdc59.js.map