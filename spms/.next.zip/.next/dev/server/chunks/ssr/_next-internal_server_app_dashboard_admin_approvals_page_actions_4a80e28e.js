module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/approvals/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_approvals_page_actions_4a80e28e.js.map