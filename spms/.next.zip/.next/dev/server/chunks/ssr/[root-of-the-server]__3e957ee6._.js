module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/dashboard/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/dashboard/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/dashboard/admin/students/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

// "use client"
// import type React from "react"
// import { useState } from "react"
// import { motion } from "framer-motion"
// import { GraduationCap, Mail, Phone, Plus, Edit2, Trash2, Award } from "lucide-react"
// import { Header } from "@/components/dashboard/header"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Avatar, AvatarFallback } from "@/components/ui/avatar"
// import { Badge } from "@/components/ui/badge"
// import { DataTable, SortableHeader } from "@/components/shared/data-table"
// import {
//   Dialog,
//   DialogContent,
//   DialogDescription,
//   DialogHeader,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog"
// import { useAppStore, type Student } from "@/lib/store"
// import { toast } from "sonner"
// import type { ColumnDef } from "@tanstack/react-table"
// export default function AdminStudentsPage() {
//   const { students, projectGroups, addStudent, updateStudent, deleteStudent } = useAppStore()
//   const [isAddOpen, setIsAddOpen] = useState(false)
//   const [editingStudent, setEditingStudent] = useState<Student | null>(null)
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     description: "",
//     cgpa: 0,
//   })
//   const handleAdd = (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!formData.name || !formData.email) {
//       toast.error("Name and email are required")
//       return
//     }
//     addStudent(formData)
//     toast.success("Student added successfully!")
//     setFormData({ name: "", email: "", phone: "", description: "", cgpa: 0 })
//     setIsAddOpen(false)
//   }
//   const handleEdit = (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!editingStudent) return
//     updateStudent(editingStudent.id, formData)
//     toast.success("Student updated successfully!")
//     setEditingStudent(null)
//     setFormData({ name: "", email: "", phone: "", description: "", cgpa: 0 })
//   }
//   const handleDelete = (id: string) => {
//     deleteStudent(id)
//     toast.success("Student deleted")
//   }
//   const openEdit = (student: Student) => {
//     setEditingStudent(student)
//     setFormData({
//       name: student.name,
//       email: student.email,
//       phone: student.phone,
//       description: student.description,
//       cgpa: student.cgpa,
//     })
//   }
//   const columns: ColumnDef<Student>[] = [
//     {
//       accessorKey: "name",
//       header: ({ column }) => <SortableHeader column={column}>Name</SortableHeader>,
//       cell: ({ row }) => (
//         <div className="flex items-center gap-3">
//           <Avatar className="h-8 w-8">
//             <AvatarFallback className="text-xs bg-accent/10">
//               {row.original.name
//                 .split(" ")
//                 .map((n) => n[0])
//                 .join("")}
//             </AvatarFallback>
//           </Avatar>
//           <div>
//             <p className="font-medium">{row.original.name}</p>
//             <p className="text-xs text-muted-foreground">{row.original.description}</p>
//           </div>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "email",
//       header: "Email",
//       cell: ({ row }) => (
//         <div className="flex items-center gap-2">
//           <Mail className="h-4 w-4 text-muted-foreground" />
//           <span className="text-sm">{row.original.email}</span>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "phone",
//       header: "Phone",
//       cell: ({ row }) => (
//         <div className="flex items-center gap-2">
//           <Phone className="h-4 w-4 text-muted-foreground" />
//           <span className="text-sm">{row.original.phone}</span>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "cgpa",
//       header: ({ column }) => <SortableHeader column={column}>CGPA</SortableHeader>,
//       cell: ({ row }) => (
//         <Badge variant="outline" className="font-mono">
//           {row.original.cgpa.toFixed(2)}
//         </Badge>
//       ),
//     },
//     {
//       id: "projects",
//       header: "Projects",
//       cell: ({ row }) => {
//         const studentGroups = projectGroups.filter((g) => g.members.some((m) => m.studentId === row.original.id))
//         return <span className="text-sm">{studentGroups.length}</span>
//       },
//     },
//     {
//       id: "actions",
//       cell: ({ row }) => (
//         <div className="flex items-center gap-2">
//           <Button variant="ghost" size="icon" onClick={() => openEdit(row.original)}>
//             <Edit2 className="h-4 w-4" />
//           </Button>
//           <Button
//             variant="ghost"
//             size="icon"
//             className="text-destructive hover:text-destructive"
//             onClick={() => handleDelete(row.original.id)}
//           >
//             <Trash2 className="h-4 w-4" />
//           </Button>
//         </div>
//       ),
//     },
//   ]
//   const StudentForm = ({ onSubmit, isEdit }: { onSubmit: (e: React.FormEvent) => void; isEdit?: boolean }) => (
//     <form onSubmit={onSubmit} className="space-y-4">
//       <div className="space-y-2">
//         <Label htmlFor="name">Name *</Label>
//         <Input
//           id="name"
//           placeholder="Enter name"
//           value={formData.name}
//           onChange={(e) => setFormData({ ...formData, name: e.target.value })}
//         />
//       </div>
//       <div className="space-y-2">
//         <Label htmlFor="email">Email *</Label>
//         <Input
//           id="email"
//           type="email"
//           placeholder="Enter email"
//           value={formData.email}
//           onChange={(e) => setFormData({ ...formData, email: e.target.value })}
//         />
//       </div>
//       <div className="grid grid-cols-2 gap-4">
//         <div className="space-y-2">
//           <Label htmlFor="phone">Phone</Label>
//           <Input
//             id="phone"
//             placeholder="Enter phone"
//             value={formData.phone}
//             onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
//           />
//         </div>
//         <div className="space-y-2">
//           <Label htmlFor="cgpa">CGPA</Label>
//           <Input
//             id="cgpa"
//             type="number"
//             step="0.01"
//             min="0"
//             max="10"
//             placeholder="Enter CGPA"
//             value={formData.cgpa}
//             onChange={(e) => setFormData({ ...formData, cgpa: Number.parseFloat(e.target.value) || 0 })}
//           />
//         </div>
//       </div>
//       <div className="space-y-2">
//         <Label htmlFor="description">Description</Label>
//         <Input
//           id="description"
//           placeholder="e.g., CSE - 4th Year"
//           value={formData.description}
//           onChange={(e) => setFormData({ ...formData, description: e.target.value })}
//         />
//       </div>
//       <div className="flex justify-end gap-2">
//         <Button type="submit">{isEdit ? "Update" : "Add"} Student</Button>
//       </div>
//     </form>
//   )
//   const avgCgpa = students.length > 0 ? students.reduce((acc, s) => acc + s.cgpa, 0) / students.length : 0
//   return (
//     <div className="min-h-screen">
//       <Header title="Student Management" description="Manage all students in the system" />
//       <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-6 space-y-6">
//         {/* Stats */}
//         <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
//           <Card className="border-border/50">
//             <CardContent className="p-6">
//               <div className="flex items-center gap-4">
//                 <div className="p-3 rounded-xl bg-accent/10">
//                   <GraduationCap className="h-6 w-6 text-accent" />
//                 </div>
//                 <div>
//                   <p className="text-2xl font-bold">{students.length}</p>
//                   <p className="text-sm text-muted-foreground">Total Students</p>
//                 </div>
//               </div>
//             </CardContent>
//           </Card>
//           <Card className="border-border/50">
//             <CardContent className="p-6">
//               <div className="flex items-center gap-4">
//                 <div className="p-3 rounded-xl bg-success/10">
//                   <Award className="h-6 w-6 text-success" />
//                 </div>
//                 <div>
//                   <p className="text-2xl font-bold">{avgCgpa.toFixed(2)}</p>
//                   <p className="text-sm text-muted-foreground">Average CGPA</p>
//                 </div>
//               </div>
//             </CardContent>
//           </Card>
//         </div>
//         {/* Students Table */}
//         <Card className="border-border/50">
//           <CardHeader className="flex flex-row items-center justify-between">
//             <div>
//               <CardTitle>All Students</CardTitle>
//               <CardDescription>Manage students in the system</CardDescription>
//             </div>
//             <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
//               <DialogTrigger asChild>
//                 <Button>
//                   <Plus className="h-4 w-4 mr-2" />
//                   Add Student
//                 </Button>
//               </DialogTrigger>
//               <DialogContent>
//                 <DialogHeader>
//                   <DialogTitle>Add New Student</DialogTitle>
//                   <DialogDescription>Fill in the details to add a new student</DialogDescription>
//                 </DialogHeader>
//                 <StudentForm onSubmit={handleAdd} />
//               </DialogContent>
//             </Dialog>
//           </CardHeader>
//           <CardContent>
//             <DataTable columns={columns} data={students} searchKey="name" searchPlaceholder="Search students..." />
//           </CardContent>
//         </Card>
//         {/* Edit Dialog */}
//         <Dialog open={!!editingStudent} onOpenChange={(open) => !open && setEditingStudent(null)}>
//           <DialogContent>
//             <DialogHeader>
//               <DialogTitle>Edit Student</DialogTitle>
//               <DialogDescription>Update student details</DialogDescription>
//             </DialogHeader>
//             <StudentForm onSubmit={handleEdit} isEdit />
//           </DialogContent>
//         </Dialog>
//       </motion.div>
//     </div>
//   )
// }
// "use client"
// import type React from "react"
// import { useEffect, useState } from "react"
// import { motion } from "framer-motion"
// import { GraduationCap, Mail, Phone, Plus, Edit2, Trash2, Award } from "lucide-react"
// import { Header } from "@/components/dashboard/header"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Avatar, AvatarFallback } from "@/components/ui/avatar"
// import { Badge } from "@/components/ui/badge"
// import { DataTable, SortableHeader } from "@/components/shared/data-table"
// import {
//   Dialog,
//   DialogContent,
//   DialogDescription,
//   DialogHeader,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog"
// import { toast } from "sonner"
// import type { ColumnDef } from "@tanstack/react-table"
// export type Student = {
//   id: string
//   name: string
//   email: string
//   phone: string
//   description: string
//   cgpa: number
// }
// export default function AdminStudentsPage() {
//   const [students, setStudents] = useState<Student[]>([])
//   const [isAddOpen, setIsAddOpen] = useState(false)
//   const [editingStudent, setEditingStudent] = useState<Student | null>(null)
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     description: "",
//     cgpa: 0,
//   })
//   /* ================= FETCH ================= */
//   const fetchStudents = async () => {
//   const res = await fetch("/api/student")
//   if (!res.ok) {
//     const text = await res.text()
//     console.error("API ERROR:", text)
//     return
//   }
//   const data = await res.json()
//   setStudents(
//     data.map((s: any) => ({
//       id: String(s.StudentID),
//       name: s.StudentName,
//       email: s.Email,
//       phone: s.Phone ?? "",
//       description: s.Description ?? "",
//       cgpa: 0,
//     }))
//   )
// }
//   useEffect(() => {
//     fetchStudents()
//   }, [])
//   /* ================= ADD ================= */
//   const handleAdd = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!formData.name || !formData.email) {
//       toast.error("Name and Email required")
//       return
//     }
//     await fetch("/api/student", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({
//         StudentName: formData.name,
//         Phone: formData.phone,
//         Email: formData.email,
//         Password: "123456",
//         Description: formData.description,
//         CGPA: formData.cgpa,
//       }),
//     })
//     toast.success("Student added")
//     setIsAddOpen(false)
//     setFormData({ name: "", email: "", phone: "", description: "", cgpa: 0 })
//     fetchStudents()
//   }
//   /* ================= UPDATE ================= */
//   const handleEdit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!editingStudent) return
//     await fetch("/api/student", {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({
//         StudentID: editingStudent.id,
//         StudentName: formData.name,
//         Phone: formData.phone,
//         Email: formData.email,
//         Description: formData.description,
//         CGPA: formData.cgpa,
//       }),
//     })
//     toast.success("Student updated")
//     setEditingStudent(null)
//     fetchStudents()
//   }
//   /* ================= DELETE ================= */
//   const handleDelete = async (id: string) => {
//     await fetch("/api/student", {
//       method: "DELETE",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify({ StudentID: id }),
//     })
//     toast.success("Student deleted")
//     fetchStudents()
//   }
//   const openEdit = (student: Student) => {
//     setEditingStudent(student)
//     setFormData({
//       name: student.name,
//       email: student.email,
//       phone: student.phone,
//       description: student.description,
//       cgpa: student.cgpa,
//     })
//   }
//   /* ================= TABLE ================= */
//   const columns: ColumnDef<Student>[] = [
//     {
//       accessorKey: "name",
//       header: ({ column }) => <SortableHeader column={column}>Name</SortableHeader>,
//       cell: ({ row }) => (
//         <div className="flex items-center gap-3">
//           <Avatar className="h-8 w-8">
//             <AvatarFallback className="text-xs bg-accent/10">
//               {row.original.name
//                 .split(" ")
//                 .map((n) => n[0])
//                 .join("")}
//             </AvatarFallback>
//           </Avatar>
//           <div>
//             <p className="font-medium">{row.original.name}</p>
//             <p className="text-xs text-muted-foreground">{row.original.description}</p>
//           </div>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "email",
//       header: "Email",
//       cell: ({ row }) => (
//         <div className="flex items-center gap-2">
//           <Mail className="h-4 w-4 text-muted-foreground" />
//           <span className="text-sm">{row.original.email}</span>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "phone",
//       header: "Phone",
//       cell: ({ row }) => (
//         <div className="flex items-center gap-2">
//           <Phone className="h-4 w-4 text-muted-foreground" />
//           <span className="text-sm">{row.original.phone}</span>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "cgpa",
//       header: ({ column }) => <SortableHeader column={column}>CGPA</SortableHeader>,
//       cell: ({ row }) => (
//         <Badge variant="outline" className="font-mono">
//           {row.original.cgpa.toFixed(2)}
//         </Badge>
//       ),
//     },
//     {
//       id: "actions",
//       cell: ({ row }) => (
//         <div className="flex gap-2">
//           <Button size="icon" variant="ghost" onClick={() => openEdit(row.original)}>
//             <Edit2 className="h-4 w-4" />
//           </Button>
//           <Button
//             size="icon"
//             variant="ghost"
//             className="text-destructive"
//             onClick={() => handleDelete(row.original.id)}
//           >
//             <Trash2 className="h-4 w-4" />
//           </Button>
//         </div>
//       ),
//     },
//   ]
//   const StudentForm = ({ onSubmit }: { onSubmit: (e: React.FormEvent) => void }) => (
//     <form onSubmit={onSubmit} className="space-y-4">
//       <Label>Name</Label>
//       <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
//       <Label>Email</Label>
//       <Input value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
//       <Label>Phone</Label>
//       <Input value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
//       <Label>CGPA</Label>
//       <Input
//         type="number"
//         step="0.01"
//         value={formData.cgpa}
//         onChange={(e) => setFormData({ ...formData, cgpa: Number(e.target.value) })}
//       />
//       <Label>Description</Label>
//       <Input value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} />
//       <Button type="submit">Save</Button>
//     </form>
//   )
//   const avgCgpa = students.length ? students.reduce((a, b) => a + b.cgpa, 0) / students.length : 0
//   return (
//     <div className="min-h-screen">
//       <Header title="Student Management" description="Manage all students" />
//       <motion.div className="p-6 space-y-6">
//         <div className="grid grid-cols-2 gap-4">
//           <Card>
//             <CardContent className="p-6">
//               <GraduationCap /> {students.length} Students
//             </CardContent>
//           </Card>
//           <Card>
//             <CardContent className="p-6">
//               <Award /> Avg CGPA: {avgCgpa.toFixed(2)}
//             </CardContent>
//           </Card>
//         </div>
//         <Card>
//           <CardHeader className="flex justify-between flex-row">
//             <CardTitle>Students</CardTitle>
//             <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
//               <DialogTrigger asChild>
//                 <Button><Plus /> Add Student</Button>
//               </DialogTrigger>
//               <DialogContent>
//                 <StudentForm onSubmit={handleAdd} />
//               </DialogContent>
//             </Dialog>
//           </CardHeader>
//           <CardContent>
//             <DataTable columns={columns} data={students} />
//           </CardContent>
//         </Card>
//         <Dialog open={!!editingStudent} onOpenChange={() => setEditingStudent(null)}>
//           <DialogContent>
//             <StudentForm onSubmit={handleEdit} />
//           </DialogContent>
//         </Dialog>
//       </motion.div>
//     </div>
//   )
// }
}),
"[project]/app/dashboard/admin/students/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/dashboard/admin/students/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__3e957ee6._.js.map