module.exports = [
"[project]/app/dashboard/admin/users/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=app_dashboard_admin_users_loading_tsx_fe2a1e5d._.js.map