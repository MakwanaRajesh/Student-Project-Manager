module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/students/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_students_page_actions_525b7b1c.js.map