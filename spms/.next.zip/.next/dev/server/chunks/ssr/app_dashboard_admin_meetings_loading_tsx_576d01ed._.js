module.exports = [
"[project]/app/dashboard/admin/meetings/loading.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
function Loading() {
    return null;
}
}),
];

//# sourceMappingURL=app_dashboard_admin_meetings_loading_tsx_576d01ed._.js.map