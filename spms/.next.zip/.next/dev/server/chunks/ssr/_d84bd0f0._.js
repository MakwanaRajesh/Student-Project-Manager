module.exports = [
"[project]/lib/utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-ssr] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
}),
"[project]/components/ui/button.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "buttonVariants",
    ()=>buttonVariants
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@radix-ui/react-slot/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/class-variance-authority/dist/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
;
;
const buttonVariants = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$class$2d$variance$2d$authority$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cva"])("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive", {
    variants: {
        variant: {
            default: 'bg-primary text-primary-foreground hover:bg-primary/90',
            destructive: 'bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
            outline: 'border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:hover:bg-input/50',
            secondary: 'bg-secondary text-secondary-foreground hover:bg-secondary/80',
            ghost: 'hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50',
            link: 'text-primary underline-offset-4 hover:underline'
        },
        size: {
            default: 'h-9 px-4 py-2 has-[>svg]:px-3',
            sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5',
            lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
            icon: 'size-9',
            'icon-sm': 'size-8',
            'icon-lg': 'size-10'
        }
    },
    defaultVariants: {
        variant: 'default',
        size: 'default'
    }
});
function Button({ className, variant, size, asChild = false, ...props }) {
    const Comp = asChild ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$radix$2d$ui$2f$react$2d$slot$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Slot"] : 'button';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Comp, {
        "data-slot": "button",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])(buttonVariants({
            variant,
            size,
            className
        })),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/components/ui/input.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/utils.ts [app-ssr] (ecmascript)");
;
;
function Input({ className, type, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        type: type,
        "data-slot": "input",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cn"])('file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm', 'focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px]', 'aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive', className),
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/input.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
;
}),
"[project]/lib/store.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useAppStore",
    ()=>useAppStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-ssr] (ecmascript)");
"use client";
;
;
// Generate unique ID
const generateId = ()=>Math.random().toString(36).substr(2, 9);
// Sample data
const sampleProjectTypes = [
    {
        id: "1",
        name: "Major Project",
        description: "Final year major project",
        created: new Date(),
        modified: new Date()
    },
    {
        id: "2",
        name: "Mini Project",
        description: "Semester mini project",
        created: new Date(),
        modified: new Date()
    },
    {
        id: "3",
        name: "Research Project",
        description: "Research and development project",
        created: new Date(),
        modified: new Date()
    }
];
const sampleStaff = [
    {
        id: "1",
        name: "Dr. Rajesh Kumar",
        email: "rajesh.kumar@university.edu",
        phone: "9876543210",
        description: "Professor - Computer Science",
        created: new Date(),
        modified: new Date()
    },
    {
        id: "2",
        name: "Dr. Priya Sharma",
        email: "priya.sharma@university.edu",
        phone: "9876543211",
        description: "Associate Professor - AI/ML",
        created: new Date(),
        modified: new Date()
    },
    {
        id: "3",
        name: "Prof. Amit Patel",
        email: "amit.patel@university.edu",
        phone: "9876543212",
        description: "Professor - Software Engineering",
        created: new Date(),
        modified: new Date()
    },
    {
        id: "4",
        name: "Dr. Neha Singh",
        email: "neha.singh@university.edu",
        phone: "9876543213",
        description: "Assistant Professor - Data Science",
        created: new Date(),
        modified: new Date()
    }
];
const sampleStudents = [
    {
        id: "1",
        name: "Arjun Mehta",
        email: "arjun.m@student.edu",
        phone: "9123456780",
        description: "CSE - 4th Year",
        cgpa: 8.5,
        created: new Date(),
        modified: new Date()
    },
    {
        id: "2",
        name: "Sneha Reddy",
        email: "sneha.r@student.edu",
        phone: "9123456781",
        description: "CSE - 4th Year",
        cgpa: 9.1,
        created: new Date(),
        modified: new Date()
    },
    {
        id: "3",
        name: "Vikram Singh",
        email: "vikram.s@student.edu",
        phone: "9123456782",
        description: "CSE - 4th Year",
        cgpa: 8.8,
        created: new Date(),
        modified: new Date()
    },
    {
        id: "4",
        name: "Ananya Gupta",
        email: "ananya.g@student.edu",
        phone: "9123456783",
        description: "CSE - 4th Year",
        cgpa: 9.3,
        created: new Date(),
        modified: new Date()
    },
    {
        id: "5",
        name: "Rohan Joshi",
        email: "rohan.j@student.edu",
        phone: "9123456784",
        description: "CSE - 3rd Year",
        cgpa: 8.2,
        created: new Date(),
        modified: new Date()
    },
    {
        id: "6",
        name: "Kavya Nair",
        email: "kavya.n@student.edu",
        phone: "9123456785",
        description: "CSE - 3rd Year",
        cgpa: 8.9,
        created: new Date(),
        modified: new Date()
    }
];
const sampleProjectGroups = [
    {
        id: "1",
        name: "Team Alpha",
        projectTypeId: "1",
        guideStaffId: "1",
        guideStaffName: "Dr. Rajesh Kumar",
        projectTitle: "AI-Powered Student Analytics",
        projectArea: "Artificial Intelligence",
        projectDescription: "Developing an AI system to analyze student performance and provide personalized recommendations.",
        averageCpi: 8.7,
        convenerStaffId: "3",
        expertStaffId: "2",
        status: "approved",
        description: "",
        members: [
            {
                id: "1",
                groupId: "1",
                studentId: "1",
                isGroupLeader: true,
                cgpa: 8.5,
                description: ""
            },
            {
                id: "2",
                groupId: "1",
                studentId: "2",
                isGroupLeader: false,
                cgpa: 9.1,
                description: ""
            }
        ],
        created: new Date(),
        modified: new Date()
    },
    {
        id: "2",
        name: "Team Beta",
        projectTypeId: "1",
        guideStaffId: "2",
        guideStaffName: "Dr. Priya Sharma",
        projectTitle: "Smart Campus Navigation",
        projectArea: "Mobile Development",
        projectDescription: "Building a mobile app for campus navigation with AR features.",
        averageCpi: 9.0,
        convenerStaffId: "1",
        expertStaffId: "4",
        status: "approved",
        description: "",
        members: [
            {
                id: "3",
                groupId: "2",
                studentId: "3",
                isGroupLeader: true,
                cgpa: 8.8,
                description: ""
            },
            {
                id: "4",
                groupId: "2",
                studentId: "4",
                isGroupLeader: false,
                cgpa: 9.3,
                description: ""
            }
        ],
        created: new Date(),
        modified: new Date()
    },
    {
        id: "3",
        name: "Team Gamma",
        projectTypeId: "2",
        guideStaffId: "3",
        guideStaffName: "Prof. Amit Patel",
        projectTitle: "E-Learning Platform",
        projectArea: "Web Development",
        projectDescription: "Creating an interactive e-learning platform with video conferencing.",
        averageCpi: 8.5,
        status: "pending",
        description: "",
        members: [
            {
                id: "5",
                groupId: "3",
                studentId: "5",
                isGroupLeader: true,
                cgpa: 8.2,
                description: ""
            },
            {
                id: "6",
                groupId: "3",
                studentId: "6",
                isGroupLeader: false,
                cgpa: 8.9,
                description: ""
            }
        ],
        created: new Date(),
        modified: new Date()
    }
];
const sampleMeetings = [
    {
        id: "1",
        groupId: "1",
        guideStaffId: "1",
        dateTime: new Date(Date.now() + 86400000),
        purpose: "Project Progress Review",
        location: "Room 301, CS Building",
        notes: "Discuss progress on AI model training",
        status: "scheduled",
        statusDescription: "",
        attendance: [],
        created: new Date(),
        modified: new Date()
    },
    {
        id: "2",
        groupId: "2",
        guideStaffId: "2",
        dateTime: new Date(Date.now() - 86400000),
        purpose: "Design Review",
        location: "Conference Room A",
        notes: "UI/UX review completed. Minor changes suggested.",
        status: "completed",
        statusDescription: "",
        attendance: [
            {
                id: "1",
                meetingId: "2",
                studentId: "3",
                isPresent: true,
                remarks: ""
            },
            {
                id: "2",
                meetingId: "2",
                studentId: "4",
                isPresent: true,
                remarks: ""
            }
        ],
        created: new Date(),
        modified: new Date()
    }
];
const useAppStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["persist"])((set)=>({
        // Auth
        user: null,
        isAuthenticated: false,
        login: (user)=>set({
                user,
                isAuthenticated: true
            }),
        logout: ()=>set({
                user: null,
                isAuthenticated: false
            }),
        // Project Types
        projectTypes: sampleProjectTypes,
        addProjectType: (type)=>set((state)=>({
                    projectTypes: [
                        ...state.projectTypes,
                        {
                            ...type,
                            id: generateId(),
                            created: new Date(),
                            modified: new Date()
                        }
                    ]
                })),
        updateProjectType: (id, type)=>set((state)=>({
                    projectTypes: state.projectTypes.map((t)=>t.id === id ? {
                            ...t,
                            ...type,
                            modified: new Date()
                        } : t)
                })),
        deleteProjectType: (id)=>set((state)=>({
                    projectTypes: state.projectTypes.filter((t)=>t.id !== id)
                })),
        // Staff
        staff: sampleStaff,
        addStaff: (staff)=>set((state)=>({
                    staff: [
                        ...state.staff,
                        {
                            ...staff,
                            id: generateId(),
                            created: new Date(),
                            modified: new Date()
                        }
                    ]
                })),
        updateStaff: (id, staff)=>set((state)=>({
                    staff: state.staff.map((s)=>s.id === id ? {
                            ...s,
                            ...staff,
                            modified: new Date()
                        } : s)
                })),
        deleteStaff: (id)=>set((state)=>({
                    staff: state.staff.filter((s)=>s.id !== id)
                })),
        // Students
        students: sampleStudents,
        addStudent: (student)=>set((state)=>({
                    students: [
                        ...state.students,
                        {
                            ...student,
                            id: generateId(),
                            created: new Date(),
                            modified: new Date()
                        }
                    ]
                })),
        updateStudent: (id, student)=>set((state)=>({
                    students: state.students.map((s)=>s.id === id ? {
                            ...s,
                            ...student,
                            modified: new Date()
                        } : s)
                })),
        deleteStudent: (id)=>set((state)=>({
                    students: state.students.filter((s)=>s.id !== id)
                })),
        // Project Groups
        projectGroups: sampleProjectGroups,
        addProjectGroup: (group)=>set((state)=>({
                    projectGroups: [
                        ...state.projectGroups,
                        {
                            ...group,
                            id: generateId(),
                            created: new Date(),
                            modified: new Date()
                        }
                    ]
                })),
        updateProjectGroup: (id, group)=>set((state)=>({
                    projectGroups: state.projectGroups.map((g)=>g.id === id ? {
                            ...g,
                            ...group,
                            modified: new Date()
                        } : g)
                })),
        deleteProjectGroup: (id)=>set((state)=>({
                    projectGroups: state.projectGroups.filter((g)=>g.id !== id)
                })),
        approveProjectGroup: (id)=>set((state)=>({
                    projectGroups: state.projectGroups.map((g)=>g.id === id ? {
                            ...g,
                            status: "approved",
                            modified: new Date()
                        } : g)
                })),
        rejectProjectGroup: (id)=>set((state)=>({
                    projectGroups: state.projectGroups.map((g)=>g.id === id ? {
                            ...g,
                            status: "rejected",
                            modified: new Date()
                        } : g)
                })),
        // Meetings
        meetings: sampleMeetings,
        addMeeting: (meeting)=>set((state)=>({
                    meetings: [
                        ...state.meetings,
                        {
                            ...meeting,
                            id: generateId(),
                            created: new Date(),
                            modified: new Date()
                        }
                    ]
                })),
        updateMeeting: (id, meeting)=>set((state)=>({
                    meetings: state.meetings.map((m)=>m.id === id ? {
                            ...m,
                            ...meeting,
                            modified: new Date()
                        } : m)
                })),
        deleteMeeting: (id)=>set((state)=>({
                    meetings: state.meetings.filter((m)=>m.id !== id)
                })),
        updateAttendance: (meetingId, attendance)=>set((state)=>({
                    meetings: state.meetings.map((m)=>m.id === meetingId ? {
                            ...m,
                            attendance,
                            modified: new Date()
                        } : m)
                }))
    }), {
    name: "spms-storage"
}));
}),
"[project]/app/login/page.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LoginPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/input.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/store.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/sonner/dist/index.mjs [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
const demoUsers = {
    admin: {
        id: "admin1",
        name: "Admin User",
        email: "admin@university.edu",
        role: "admin"
    },
    faculty: {
        id: "1",
        name: "Dr. Rajesh Kumar",
        email: "rajesh.kumar@university.edu",
        role: "faculty"
    },
    student: {
        id: "1",
        name: "Arjun Mehta",
        email: "arjun.m@student.edu",
        role: "student"
    }
};
function getRedirectPath(role) {
    switch(role){
        case "student":
            return "/dashboard/student";
        case "faculty":
            return "/dashboard/faculty";
        case "admin":
            return "/dashboard/admin";
    }
}
function LoginPage() {
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRouter"])();
    const login = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$store$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useAppStore"])((state)=>state.login);
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [role, setRole] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("student");
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleLogin = async (e)=>{
        e.preventDefault();
        setIsLoading(true);
        // Simulate API call
        await new Promise((resolve)=>setTimeout(resolve, 1000));
        const user = demoUsers[role];
        login(user);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`Welcome, ${user.name}!`);
        router.push(getRedirectPath(role));
        setIsLoading(false);
    };
    const handleDemoLogin = async (demoRole)=>{
        setIsLoading(true);
        await new Promise((resolve)=>setTimeout(resolve, 500));
        const user = demoUsers[demoRole];
        login(user);
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$sonner$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["toast"].success(`Welcome, ${user.name}!`);
        router.push(getRedirectPath(demoRole));
        setIsLoading(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                type: "email",
                placeholder: "Email",
                value: email,
                onChange: (e)=>setEmail(e.target.value)
            }, void 0, false, {
                fileName: "[project]/app/login/page.tsx",
                lineNumber: 75,
                columnNumber: 3
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$input$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Input"], {
                type: "password",
                placeholder: "Password",
                value: password,
                onChange: (e)=>setPassword(e.target.value)
            }, void 0, false, {
                fileName: "[project]/app/login/page.tsx",
                lineNumber: 82,
                columnNumber: 3
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Button"], {
                type: "button",
                onClick: async ()=>{
                    console.log("CLICKED");
                    const res = await fetch("/api/auth/login", {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            email,
                            password,
                            role
                        })
                    });
                    console.log("STATUS:", res.status);
                    const text = await res.text();
                    console.log("RAW RESPONSE:", text);
                    if (text) {
                        console.log("PARSED:", JSON.parse(text));
                    }
                },
                children: "Test Login"
            }, void 0, false, {
                fileName: "[project]/app/login/page.tsx",
                lineNumber: 89,
                columnNumber: 3
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/login/page.tsx",
        lineNumber: 74,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=_d84bd0f0._.js.map