module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/dashboard/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/dashboard/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/app/dashboard/admin/project-types/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {

// "use client"
// import type React from "react"
// import { useEffect, useState } from "react"
// import { motion } from "framer-motion"
// import { Settings, Plus, Edit2, Trash2, FolderKanban } from "lucide-react"
// import { Header } from "@/components/dashboard/header"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Textarea } from "@/components/ui/textarea"
// import {
//   Dialog,
//   DialogContent,
//   DialogDescription,
//   DialogHeader,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog"
// // import { useAppStore, type ProjectType } from "@/lib/store"
// import { toast } from "sonner"
// type ProjectType = {
//   id: string
//   name: string
//   description: string
// }
// export default function AdminProjectTypesPage() {
//   const [ projectTypes, setProjectTypes ] = useState<ProjectType[]>([])
//   const [ projectGroups ] = useState<any[]>([])
//   // const { projectTypes, projectGroups, addProjectType, updateProjectType, deleteProjectType } = useAppStore()
//   const [isAddOpen, setIsAddOpen] = useState(false)
//   const [editingType, setEditingType] = useState<ProjectType | null>(null)
//   const [formData, setFormData] = useState({
//     name: "",
//     description: "",
//   })
//   const loadProjectTypes = async () => {
//     try{
//       const res = await fetch("/api/project-types")
//       const data = await res.json()
//       setProjectTypes(data)
//     } catch {
//       toast.error("Failed to load project types")
//     }
//   }
//   useEffect(() => {
//     loadProjectTypes()
//   }, [])
//   const handleAdd = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!formData.name.trim()) {
//       toast.error("Name is required")
//       return
//     }
//     await fetch("/api/project-types", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(formData)
//     })
//     toast.success("Project type added successfully")
//     setFormData({ name: "", description: "" })
//     setIsAddOpen(false)
//     loadProjectTypes()
//     // addProjectType(formData)
//     // toast.success("Project type added successfully!")
//     // setFormData({ name: "", description: "" })
//     // setIsAddOpen(false)
//   }
//   const handleEdit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!editingType) return
//     await fetch(`/api/project-types/${editingType.id}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(formData)
//     })
//     toast.success("Project type updated successfully")
//     setEditingType(null)
//     setFormData({ name: "", description: "" })
//     loadProjectTypes()
//     // updateProjectType(editingType.id, formData)
//     // toast.success("Project type updated successfully!")
//     // setEditingType(null)
//     // setFormData({ name: "", description: "" })
//   }
//   const handleDelete = async (id: string) => {
//     await fetch(`/api/project-types/${id}`, { method: "DELETE" })
//     toast.success("Project type deleted")
//     loadProjectTypes()
//     // const projectsUsingType = projectGroups.filter((g) => g.projectTypeId === id)
//     // if (projectsUsingType.length > 0) {
//     //   toast.error(`Cannot delete: ${projectsUsingType.length} projects using this type`)
//     //   return
//     // }
//     // deleteProjectType(id)
//     // toast.success("Project type deleted")
//   }
//   const openEdit = (type: ProjectType) => {
//     setEditingType(type)
//     setFormData({
//       name: type.name,
//       description: type.description,
//     })
//   }
//   const TypeForm = ({ onSubmit, isEdit }: { onSubmit: (e: React.FormEvent) => void; isEdit?: boolean }) => (
//     <form onSubmit={onSubmit} className="space-y-4">
//       <div className="space-y-2">
//         <Label htmlFor="name">Name *</Label>
//         <Input
//           id="name"
//           placeholder="Enter project type name"
//           value={formData.name}
//           onChange={(e) => setFormData({ ...formData, name: e.target.value })}
//         />
//       </div>
//       <div className="space-y-2">
//         <Label htmlFor="description">Description</Label>
//         <Textarea
//           id="description"
//           placeholder="Enter description"
//           value={formData.description}
//           onChange={(e) => setFormData({ ...formData, description: e.target.value })}
//         />
//       </div>
//       <div className="flex justify-end gap-2">
//         <Button type="submit">{isEdit ? "Update" : "Add"} Type</Button>
//       </div>
//     </form>
//   )
//   return (
//     <div className="min-h-screen">
//       <Header title="Project Types" description="Manage project type configurations" />
//       <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-6 space-y-6">
//         {/* Stats */}
//         <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//           <Card className="border-border/50">
//             <CardContent className="p-6">
//               <div className="flex items-center gap-4">
//                 <div className="p-3 rounded-xl bg-warning/10">
//                   <Settings className="h-6 w-6 text-warning" />
//                 </div>
//                 <div>
//                   <p className="text-2xl font-bold">{projectTypes.length}</p>
//                   <p className="text-sm text-muted-foreground">Project Types</p>
//                 </div>
//               </div>
//             </CardContent>
//           </Card>
//         </div>
//         {/* Project Types */}
//         <Card className="border-border/50">
//           <CardHeader className="flex flex-row items-center justify-between">
//             <div>
//               <CardTitle>All Project Types</CardTitle>
//               <CardDescription>Configure project type categories</CardDescription>
//             </div>
//             <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
//               <DialogTrigger asChild>
//                 <Button>
//                   <Plus className="h-4 w-4 mr-2" />
//                   Add Type
//                 </Button>
//               </DialogTrigger>
//               <DialogContent>
//                 <DialogHeader>
//                   <DialogTitle>Add Project Type</DialogTitle>
//                   <DialogDescription>Create a new project type category</DialogDescription>
//                 </DialogHeader>
//                 <TypeForm onSubmit={handleAdd} />
//               </DialogContent>
//             </Dialog>
//           </CardHeader>
//           <CardContent>
//             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
//               {projectTypes.map((type) => {
//                 const projectsCount = projectGroups.filter((g) => g.projectTypeId === type.id).length
//                 return (
//                   <div
//                     key={type.id}
//                     className="p-6 rounded-xl border border-border/50 hover:border-primary/30 transition-colors"
//                   >
//                     <div className="flex items-start justify-between">
//                       <div className="p-3 rounded-xl bg-primary/10">
//                         <FolderKanban className="h-6 w-6 text-primary" />
//                       </div>
//                       <div className="flex items-center gap-1">
//                         <Button variant="ghost" size="icon" onClick={() => openEdit(type)}>
//                           <Edit2 className="h-4 w-4" />
//                         </Button>
//                         <Button
//                           variant="ghost"
//                           size="icon"
//                           className="text-destructive hover:text-destructive"
//                           onClick={() => handleDelete(type.id)}
//                         >
//                           <Trash2 className="h-4 w-4" />
//                         </Button>
//                       </div>
//                     </div>
//                     <h3 className="font-semibold mt-4">{type.name}</h3>
//                     <p className="text-sm text-muted-foreground mt-1">{type.description}</p>
//                     <div className="mt-4 pt-4 border-t border-border/50">
//                       <p className="text-sm text-muted-foreground">{projectsCount} projects using this type</p>
//                     </div>
//                   </div>
//                 )
//               })}
//             </div>
//           </CardContent>
//         </Card>
//         {/* Edit Dialog */}
//         <Dialog open={!!editingType} onOpenChange={(open) => !open && setEditingType(null)}>
//           <DialogContent>
//             <DialogHeader>
//               <DialogTitle>Edit Project Type</DialogTitle>
//               <DialogDescription>Update project type details</DialogDescription>
//             </DialogHeader>
//             <TypeForm onSubmit={handleEdit} isEdit />
//           </DialogContent>
//         </Dialog>
//       </motion.div>
//     </div>
//   )
// }
// "use client"
// import { useEffect, useState } from "react"
// import { motion } from "framer-motion"
// import { Plus, Edit2, Trash2, FolderKanban } from "lucide-react"
// import { Header } from "@/components/dashboard/header"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { DataTable, SortableHeader } from "@/components/shared/data-table"
// import {
//   Dialog,
//   DialogContent,
//   DialogDescription,
//   DialogFooter,
//   DialogHeader,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Textarea } from "@/components/ui/textarea"
// import {
//   AlertDialog,
//   AlertDialogAction,
//   AlertDialogCancel,
//   AlertDialogContent,
//   AlertDialogDescription,
//   AlertDialogFooter,
//   AlertDialogHeader,
//   AlertDialogTitle,
// } from "@/components/ui/alert-dialog"
// import { toast } from "sonner"
// import type { ColumnDef } from "@tanstack/react-table"
// /* ===================== TYPES ===================== */
// type ProjectType = {
//   id: string
//   name: string
//   description: string
//   created: Date
// }
// export default function ProjectTypesPage() {
//   const [projectTypes, setProjectTypes] = useState<ProjectType[]>([])
//   const [isDialogOpen, setIsDialogOpen] = useState(false)
//   const [editingType, setEditingType] = useState<ProjectType | null>(null)
//   const [deleteId, setDeleteId] = useState<string | null>(null)
//   const [formData, setFormData] = useState({ name: "", description: "" })
//   /* ===================== FETCH ===================== */
//   const fetchProjectTypes = async () => {
//     const res = await fetch("/api/project-types")
//     const data = await res.json()
//     setProjectTypes(
//       data.map((p: any) => ({
//         id: String(p.ProjectTypeID),
//         name: p.ProjectTypeName,
//         description: p.Description ?? "",
//         created: new Date(p.Created),
//       }))
//     )
//   }
//   useEffect(() => {
//     fetchProjectTypes()
//   }, [])
//   /* ===================== ADD / UPDATE ===================== */
//   const handleSubmit = async () => {
//     if (!formData.name.trim()) {
//       toast.error("Please enter a project type name")
//       return
//     }
//     if (editingType) {
//       await fetch(`/api/project-types/${editingType.id}`, {
//         method: "PUT",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           ProjectTypeName: formData.name,
//           Description: formData.description,
//         }),
//       })
//       toast.success("Project type updated")
//     } else {
//       await fetch("/api/project-types", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify({
//           ProjectTypeName: formData.name,
//           Description: formData.description,
//         }),
//       })
//       toast.success("Project type added")
//     }
//     setIsDialogOpen(false)
//     setEditingType(null)
//     setFormData({ name: "", description: "" })
//     fetchProjectTypes()
//   }
//   /* ===================== EDIT ===================== */
//   const handleEdit = (type: ProjectType) => {
//     setEditingType(type)
//     setFormData({ name: type.name, description: type.description })
//     setIsDialogOpen(true)
//   }
//   /* ===================== DELETE ===================== */
//   const handleDelete = async () => {
//     if (!deleteId) return
//     await fetch(`/api/project-types/${deleteId}`, {
//       method: "DELETE",
//     })
//     toast.success("Project type deleted")
//     setDeleteId(null)
//     fetchProjectTypes()
//   }
//   /* ===================== TABLE ===================== */
//   const columns: ColumnDef<ProjectType>[] = [
//     {
//       accessorKey: "name",
//       header: ({ column }) => <SortableHeader column={column}>Name</SortableHeader>,
//       cell: ({ row }) => (
//         <div className="flex items-center gap-3">
//           <div className="p-2 rounded-lg bg-primary/10">
//             <FolderKanban className="h-4 w-4 text-primary" />
//           </div>
//           <span className="font-medium">{row.getValue("name")}</span>
//         </div>
//       ),
//     },
//     {
//       accessorKey: "description",
//       header: "Description",
//       cell: ({ row }) => (
//         <span className="text-muted-foreground">{row.getValue("description") || "-"}</span>
//       ),
//     },
//     {
//       accessorKey: "created",
//       header: ({ column }) => <SortableHeader column={column}>Created</SortableHeader>,
//       cell: ({ row }) => {
//         const date = row.getValue("created") as Date
//         return <span className="text-muted-foreground">{date.toLocaleDateString()}</span>
//       },
//     },
//     {
//       id: "actions",
//       cell: ({ row }) => (
//         <div className="flex items-center gap-2">
//           <Button variant="ghost" size="icon" onClick={() => handleEdit(row.original)}>
//             <Edit2 className="h-4 w-4" />
//           </Button>
//           <Button
//             variant="ghost"
//             size="icon"
//             className="text-destructive"
//             onClick={() => setDeleteId(row.original.id)}
//           >
//             <Trash2 className="h-4 w-4" />
//           </Button>
//         </div>
//       ),
//     },
//   ]
//   return (
//     <div className="min-h-screen">
//       <Header title="Project Types" description="Manage project categories for student projects" />
//       <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="p-6">
//         <Card className="border-border/50">
//           <CardHeader className="flex flex-row items-center justify-between">
//             <div>
//               <CardTitle>All Project Types</CardTitle>
//               <CardDescription>Configure project categories like Major, Mini, and Research projects</CardDescription>
//             </div>
//             <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
//               <DialogTrigger asChild>
//                 <Button
//                   onClick={() => {
//                     setEditingType(null)
//                     setFormData({ name: "", description: "" })
//                   }}
//                 >
//                   <Plus className="h-4 w-4 mr-2" />
//                   Add Project Type
//                 </Button>
//               </DialogTrigger>
//               <DialogContent>
//                 <DialogHeader>
//                   <DialogTitle>{editingType ? "Edit Project Type" : "Add Project Type"}</DialogTitle>
//                   <DialogDescription>
//                     {editingType
//                       ? "Update the project type details below."
//                       : "Enter the details for the new project type."}
//                   </DialogDescription>
//                 </DialogHeader>
//                 <div className="space-y-4 py-4">
//                   <div className="space-y-2">
//                     <Label>Name</Label>
//                     <Input
//                       value={formData.name}
//                       onChange={(e) => setFormData({ ...formData, name: e.target.value })}
//                     />
//                   </div>
//                   <div className="space-y-2">
//                     <Label>Description</Label>
//                     <Textarea
//                       value={formData.description}
//                       onChange={(e) => setFormData({ ...formData, description: e.target.value })}
//                     />
//                   </div>
//                 </div>
//                 <DialogFooter>
//                   <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
//                     Cancel
//                   </Button>
//                   <Button onClick={handleSubmit}>
//                     {editingType ? "Update" : "Add"} Project Type
//                   </Button>
//                 </DialogFooter>
//               </DialogContent>
//             </Dialog>
//           </CardHeader>
//           <CardContent>
//             <DataTable
//               columns={columns}
//               data={projectTypes}
//               searchKey="name"
//               searchPlaceholder="Search project types..."
//             />
//           </CardContent>
//         </Card>
//         <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
//           <AlertDialogContent>
//             <AlertDialogHeader>
//               <AlertDialogTitle>Are you sure?</AlertDialogTitle>
//               <AlertDialogDescription>
//                 This action cannot be undone and will permanently delete the project type.
//               </AlertDialogDescription>
//             </AlertDialogHeader>
//             <AlertDialogFooter>
//               <AlertDialogCancel>Cancel</AlertDialogCancel>
//               <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground">
//                 Delete
//               </AlertDialogAction>
//             </AlertDialogFooter>
//           </AlertDialogContent>
//         </AlertDialog>
//       </motion.div>
//     </div>
//   )
// }
// here full complete 
// "use client"
// import type React from "react"
// import { useEffect, useState } from "react"
// import { motion } from "framer-motion"
// import { Settings, Plus, Edit2, Trash2, FolderKanban } from "lucide-react"
// import { Header } from "@/components/dashboard/header"
// import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
// import { Button } from "@/components/ui/button"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Textarea } from "@/components/ui/textarea"
// import {
//   Dialog,
//   DialogContent,
//   DialogDescription,
//   DialogHeader,
//   DialogTitle,
//   DialogTrigger,
// } from "@/components/ui/dialog"
// import { toast } from "sonner"
// type ProjectType = {
//   id: string
//   name: string
//   description: string
// }
// export default function AdminProjectTypesPage() {
//   const [projectTypes, setProjectTypes] = useState<ProjectType[]>([])
//   const [projectGroups] = useState<any[]>([]) // kept to avoid UI change
//   const [isAddOpen, setIsAddOpen] = useState(false)
//   const [editingType, setEditingType] = useState<ProjectType | null>(null)
//   const [formData, setFormData] = useState({
//     name: "",
//     description: "",
//   })
//   /* ========= FETCH LIST ========= */
//   const loadProjectTypes = async () => {
//     try {
//       const res = await fetch("/api/project-types")
//       const data = await res.json()
//       setProjectTypes(data)
//     } catch {
//       toast.error("Failed to load project types")
//     }
//   }
//   useEffect(() => {
//     loadProjectTypes()
//   }, [])
//   /* ========= ADD ========= */
//   const handleAdd = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!formData.name.trim()) {
//       toast.error("Name is required")
//       return
//     }
//     await fetch("/api/project-types", {
//       method: "POST",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(formData),
//     })
//     toast.success("Project type added successfully")
//     setFormData({ name: "", description: "" })
//     setIsAddOpen(false)
//     loadProjectTypes()
//   }
//   /* ========= EDIT ========= */
//   const handleEdit = async (e: React.FormEvent) => {
//     e.preventDefault()
//     if (!editingType) return
//     await fetch(`/api/project-types/${editingType.id}`, {
//       method: "PUT",
//       headers: { "Content-Type": "application/json" },
//       body: JSON.stringify(formData),
//     })
//     toast.success("Project type updated successfully")
//     setEditingType(null)
//     setFormData({ name: "", description: "" })
//     loadProjectTypes()
//   }
//   /* ========= DELETE ========= */
//   const handleDelete = async (id: string) => {
//     await fetch(`/api/project-types/${id}`, { method: "DELETE" })
//     toast.success("Project type deleted")
//     loadProjectTypes()
//   }
//   const openEdit = (type: ProjectType) => {
//     setEditingType(type)
//     setFormData({ name: type.name, description: type.description })
//   }
//   const TypeForm = ({ onSubmit, isEdit }: any) => (
//     <form onSubmit={onSubmit} className="space-y-4">
//       <div className="space-y-2">
//         <Label>Name *</Label>
//         <Input
//           value={formData.name}
//           onChange={(e) => setFormData({ ...formData, name: e.target.value })}
//         />
//       </div>
//       <div className="space-y-2">
//         <Label>Description</Label>
//         <Textarea
//           value={formData.description}
//           onChange={(e) => setFormData({ ...formData, description: e.target.value })}
//         />
//       </div>
//       <div className="flex justify-end">
//         <Button type="submit">{isEdit ? "Update" : "Add"} Type</Button>
//       </div>
//     </form>
//   )
//   return (
//     <div className="min-h-screen">
//       <Header title="Project Types" description="Manage project type configurations" />
//       <motion.div className="p-6 space-y-6">
//         <Card>
//           <CardContent className="p-6">
//             <p className="text-2xl font-bold">{projectTypes.length}</p>
//             <p className="text-sm text-muted-foreground">Project Types</p>
//           </CardContent>
//         </Card>
//         <Card>
//           <CardHeader className="flex flex-row justify-between">
//             <div>
//               <CardTitle>All Project Types</CardTitle>
//               <CardDescription>Configure project type categories</CardDescription>
//             </div>
//             <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
//               <DialogTrigger asChild>
//                 <Button><Plus className="mr-2 h-4 w-4" />Add Type</Button>
//               </DialogTrigger>
//               <DialogContent>
//                 <DialogHeader>
//                   <DialogTitle>Add Project Type</DialogTitle>
//                 </DialogHeader>
//                 <TypeForm onSubmit={handleAdd} />
//               </DialogContent>
//             </Dialog>
//           </CardHeader>
//           <CardContent>
//             <div className="grid md:grid-cols-3 gap-4">
//               {projectTypes.map((type) => (
//                 <div key={type.id} className="p-6 border rounded-xl">
//                   <div className="flex justify-between">
//                     <FolderKanban />
//                     <div className="flex gap-1">
//                       <Button size="icon" variant="ghost" onClick={() => openEdit(type)}>
//                         <Edit2 />
//                       </Button>
//                       <Button size="icon" variant="ghost" onClick={() => handleDelete(type.id)}>
//                         <Trash2 />
//                       </Button>
//                     </div>
//                   </div>
//                   <h3 className="mt-4 font-semibold">{type.name}</h3>
//                   <p className="text-sm text-muted-foreground">{type.description}</p>
//                 </div>
//               ))}
//             </div>
//           </CardContent>
//         </Card>
//         <Dialog open={!!editingType} onOpenChange={() => setEditingType(null)}>
//           <DialogContent>
//             <DialogHeader>
//               <DialogTitle>Edit Project Type</DialogTitle>
//             </DialogHeader>
//             <TypeForm onSubmit={handleEdit} isEdit />
//           </DialogContent>
//         </Dialog>
//       </motion.div>
//     </div>
//   )
// }
}),
"[project]/app/dashboard/admin/project-types/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/dashboard/admin/project-types/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__a8d00918._.js.map