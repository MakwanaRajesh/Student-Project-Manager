module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/reports/attendance/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_dashboard_admin_reports_attendance_page_actions_8f3d0957.js.map