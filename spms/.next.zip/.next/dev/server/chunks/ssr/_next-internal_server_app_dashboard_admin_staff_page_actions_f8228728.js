module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/staff/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_staff_page_actions_f8228728.js.map