module.exports = [
"[project]/.next-internal/server/app/dashboard/admin/project-types/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_admin_project-types_page_actions_ac8828f9.js.map